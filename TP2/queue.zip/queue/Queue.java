package queue;

public class Queue {

  public boolean isEmpty() {
		// TODO Auto-generated method stub
		return true;
	}

	public Queue add( Object  cargo ) {
		// TODO Auto-generated method stub
		return this;
	}

	public Object take() {
    // TODO Auto-generated method stub
		return null;
	}

	public Object head() {
		// TODO Auto-generated method stub
    return null;
	}

	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

}
